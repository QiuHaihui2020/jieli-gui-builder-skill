<template>
  <div class="common-layout">
    <el-container>
      <el-header><h1>视频(GIF)转图片工具</h1></el-header>
      <el-main>
        <el-row :gutter="20">
          <el-col :span="4">
            <el-text type="primary">工具说明:</el-text>
          </el-col>
          <el-col :span="20" style="text-align: left;">
            <el-text type="info">
              视频转图片插件工具，支持将视频或者GIF图片，转换成一系列的图片<br>
              方便给图片列表控件使用，或者给帧动画控件使用<br>
              这样程序就不需要支持gif解码库和视频解码库。<br>
              工具采用FFmpeg工具进行转换<br>
              <el-text type="primary">
                ffmpeg -i test.gif output/test_%04d.png <br>
                ffmpeg -i test.mp4 -vf "fps=1" output/output_%04d.png
              </el-text>
              <br>
              -i 表示输入文件，-vf 表示视频过滤器，"fps=1" 表示每秒生成一张图片<br>
            </el-text>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="4">
            <el-text class="" type="primary">FFmpeg文件:</el-text>
          </el-col>
          <el-col :span="16">
            <el-input v-model="ffmpegPath" placeholder="请选择FFmpeg程序 C:\video\ffmpeg.exe"></el-input>
          </el-col>
          <el-col :span="2">
            <el-button type="primary" @click="chooseFFmpeg">选择</el-button>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="4">
            <el-text class="" type="primary">视频文件:</el-text>
          </el-col>
          <el-col :span="16">
            <el-input v-model="videoPath" placeholder="请选择文件 C:\video\test.mp4"></el-input>
          </el-col>
          <el-col :span="2">
            <el-button type="primary" @click="chooseVideo">选择</el-button>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="4">
            <el-text class="" type="primary">保存路径:</el-text>
          </el-col>
          <el-col :span="16">
            <el-input v-model="imagesPath" placeholder="请选择需要保存的目录 C:\video\output"></el-input>
          </el-col>
          <el-col :span="2">
            <el-button type="primary" @click="chooseImages">选择</el-button>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="4">
            <el-text class="" type="primary">转换参数:</el-text>
          </el-col>
          <el-col :span="18">
            <el-input v-model="tranArgs" placeholder="FFMpeg参数"></el-input>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="4">
            <el-text class="" type="primary">预览命令:</el-text>
          </el-col>
          <el-col :span="18">
            <el-input  type="textarea" :rows="4" v-model="previewCmd" placeholder="预览待执行FFMpeg命令行" disabled></el-input>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="24">
            <el-button type="info" @click="preView">预览命令</el-button>
            <el-button type="primary" @click="tran" :loading="tranStatus">开始转换</el-button>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">
            <el-text class="" type="primary">执行日志:</el-text>
          </el-col>
          <el-col :span="18">
            <el-input type="textarea" :rows="10" placeholder="输出执行日志" disabled v-model="logMsg"></el-input>
          </el-col>
        </el-row>
      </el-main>

    </el-container>
  </div>
</template>

<script setup>
/* eslint-disable */
import { ElNotification } from "element-plus";
import { ref } from "vue";

const videoPath = ref("");
const imagesPath = ref("");
const tranArgs = ref(`-vf "fps=5"`);
const previewCmd = ref("");
const logMsg = ref("");
const tranStatus = ref(false);
const ffmpegPath = ref('"' + electronApi.getPublishPath().replaceAll('\\', '/') + '/tools/environment/external_tool/ffmpeg"');

async function chooseFFmpeg(){
  const res = await electronApi.dialogOpenSelect({
    buttonLabel: "选择",
    title: "选择FFmpeg文件",
    filters: [{name: "可执行文件", extensions: ["exe"]}],
    properties: ['openFile']
  })
  if(res){
    ffmpegPath.value = '"' + res[0] + '"';
  }
}
//选择视频文件
async function chooseVideo() {
  const res = await electronApi.dialogOpenSelect({
    buttonLabel: "选择",
    title: "选择视频文件",
    filters: [{name: "视频文件", extensions: ["mp4", "avi", "gif"]}, {name: '所有', extensions: ["*"]}],
    properties: ['openFile']
  })
  if(res){
    videoPath.value = res[0];
  }
}
async function chooseImages(){
  const res = await electronApi.dialogOpenSelect({
    buttonLabel: "选择",
    title: "选择保存目录",
    properties: ['openDirectory']
  })
  if(res){
    imagesPath.value = res[0];
  }
}
const preView = () => {
  var cmd = `${ffmpegPath.value} -i ${videoPath.value} ${tranArgs.value} ${imagesPath.value}\\output_%04d.png`;
  previewCmd.value = cmd;
};

async function tran() {
  var cmd = `${ffmpegPath.value} -i ${videoPath.value} ${tranArgs.value} ${imagesPath.value}\\output_%04d.png`;
  previewCmd.value = cmd;
  tranStatus.value = true;

  var output = "";
  await electronApi.childProcessExecByCodePage(cmd, {}, (res) => {
    if(res.type == 'output'){
      output += res.msg;
    }else if(res.type == 'error'){
      output += res.msg;
    }else if(res.type == 'exit'){
      ElNotification({
        title: "提示",
        message: "命令执行成功，执行结果是否正确，请查看输出日志",
        type: "success",
      });
    }
    logMsg.value = output;
  })
  tranStatus.value = false;
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.el-row {
  margin-bottom: 20px;
}
.el-row:last-child {
  margin-bottom: 0;
}
.el-col {
  border-radius: 4px;
}

.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.ep-bg-purple {
  background: #d3dce6;
}
</style>
